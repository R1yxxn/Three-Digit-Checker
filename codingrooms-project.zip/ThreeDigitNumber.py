threeDig = str(input("Enter a Three Digit number: "))
no3 = len(threeDig)
if no3 == 3:
    print("YES")
else:
    print("NO")